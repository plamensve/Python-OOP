from project.car import Car
from project.sports_car import SportsCar

sports_car = SportsCar()
print(sports_car.move())
print(sports_car.drive())
print(sports_car.race())
car = Car()
print(car.drive())
print(car.move())