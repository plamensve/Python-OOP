class Animal:
    def eat(self):
        return f"eating..."